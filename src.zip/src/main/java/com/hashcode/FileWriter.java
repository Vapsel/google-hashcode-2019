package com.hashcode;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class FileWriter {

    public void writeToFile(String outputFile, ArrayList<ArrayList<Integer>> slideToPhotoIds) throws IOException {
        PrintWriter writer = new PrintWriter(outputFile, StandardCharsets.UTF_8);
        writer.println(slideToPhotoIds.size());

        for (ArrayList<Integer> slide : slideToPhotoIds) {
            StringBuilder stringBuilder = new StringBuilder();
            if (slide.size() == 1){
                stringBuilder.append(slide.get(0));
            } else {
                stringBuilder.append(slide.get(0)).append(" ").append(slide.get(1));
            }
            writer.println(stringBuilder.toString());
        }
        writer.close();
    }
}
