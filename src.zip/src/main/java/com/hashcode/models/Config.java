package com.hashcode.models;

public class Config {

    public Integer NUMBER_OF_PHOTOS;
}
