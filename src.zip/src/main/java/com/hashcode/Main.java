package com.hashcode;

import com.hashcode.models.Photo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main {

    static HashMap<String, List<Integer>> tagToPhotoIds = new HashMap<>();
    static Map<String, List<Integer>> positionToPhotoIds = new HashMap<>();

    static {
        positionToPhotoIds.put("H", new ArrayList<>());
        positionToPhotoIds.put("V", new ArrayList<>());
    }

    public static void main(String[] args) throws IOException {
        String inputFile = args[0];
        List<Photo> photos = new FileParser().readFromFile(inputFile);

        compute(photos);

        String outputFile = args[1];
//        new FileWriter().writeToFile(outputFile);
    }

    public static void compute(List<Photo> photos){


        ArrayList<ArrayList<Integer>> slideToPhotoIds = new ArrayList<>();
    }

    public static int interestFactor(Photo photo1, Photo photo2){
        Set<String> intersection = new HashSet<>(photo1.tags);
        intersection.retainAll(photo2.tags);

        return Math.min(intersection.size(), Math.min(photo1.tagCount, photo2.tagCount));
    }
}
